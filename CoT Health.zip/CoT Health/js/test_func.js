

function getstatus() {
    rng = Math.floor(Math.random() * 3);
    if (rng === 1){
        fake_status = "Bracelet ON";
    }
    else if (rng === 0){
        fake_status = "Bracelet OFF";
    }
    else if (rng === 2){
        fake_status = "Bracelet Malfunction";
    }
    else {
        console.log("Something went wrong!");
    }
    document.getElementById("status").innerHTML = fake_status
    console.log("status changed");
}



var type = ["Esp32","Arduino"]
var home = ["Lerkendal","Moholt","Tyholt","Bakklandet","Midtbyen","Møllenberg","Solsiden","Singsaker"]
var connection = ["USB", "WiFi", "Bluetooth"]

function random_device(no){
    console.log("Generating data for random device :)")
    no = String(no)
    random_type = type[Math.floor(Math.random()*type.length)];
    random_home = home[Math.floor(Math.random()*home.length)];
    random_connection = connection[Math.floor(Math.random()*connection.length)];

    document.getElementById("device-div-"+no).style = "display: block;"
    document.getElementById("dev"+no+"_connection").innerHTML = "Tilkobling: "+random_connection;
    document.getElementById("dev"+no+"_type").innerHTML = random_type;
    document.getElementById("dev"+no+"_home").innerHTML = "Sted: "+random_home;

    if (random_type.toLowerCase() === "arduino") {
        image1 = document.getElementById('dev'+no+'_pic');
        image1.src = "bilder/arduinouno1.jpg"
        image1.style = "width: 500px; margin-top: 100px; align-items: flex-end"
    }
    else if (random_type.toLowerCase() === "esp32") {
        image2 = document.getElementById('dev'+no+'_pic');
        image2.src = "bilder/esp32_1.jpg"
        image2.style = "width: 400px; margin-top: 100px; align-items: flex-end"
    }
    else {
        console.log("Type not supported")
    }
}


function testgraph() {
    let peakbpm = 0;
    let peakhigh = 5;
    let peaklow = 0;
    console.log("Testing....")
    setInterval(function(){
        data1 = Math.floor(Math.random() * 50)-25;
        if (data1 <= peaklow) {
            peaklow += (data1-peaklow);
            console.log("l")
            document.getElementById("peak-low").innerHTML = "Min: "+peaklow;
        }
        else if (data1 >= peakhigh) {
            peakhigh += (data1-peakhigh);
            console.log("h")
            document.getElementById("peak-high").innerHTML = "Max: "+peakhigh;
        }
        else {
            console.log("No new peak")
        }
        dataArr1.push(data1);
        dataArr1.shift();
        label1.push(getTime());
        label1.shift()
        myLineChart.update();
        data2 = Math.floor(Math.random() * 60)+60;
        if (data2 >= peakbpm) {
            peakbpm += (data2-peakbpm)
            document.getElementById("peak-bpm").innerHTML = peakbpm+"BPM";
        }
        dataArr2.push(data2);
        dataArr2.shift();
        label1.push(getTime());
        label1.shift();
        myLineChart2.update();
        console.log("Done 1")
    }, 1000);
}

function testmap(){
    var fake_lat = (Math.random() * (0.03000)+63.42814).toFixed(5)
    var fake_lon = (Math.random() * (0.03000)+10.39517).toFixed(5);
    var mapProp= {
        center:new google.maps.LatLng(fake_lat,fake_lon),
        zoom:15,
    };
    const map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
    new google.maps.Marker({
        position: (LatLng(fake_lat,fake_lon)),
        map,
        title: "Hello World!",
    });
    marker.setMap(map);
}

function plotlive() {
    return setInterval(function(){

        dataArr3.push(100);
        dataArr3.shift();
        label2.push(getTime());
        label2.shift();

        dataArr3.push(90+100);
        dataArr3.shift();
        label2.push(getTime());
        label2.shift();

        dataArr3.push(-90+100);
        dataArr3.shift();
        label2.push(getTime());
        label2.shift();

        dataArr3.push(120);
        dataArr3.shift();
        label2.push(getTime());
        label2.shift();

        dataArr3.push(100);
        dataArr3.shift();
        label2.push(getTime());
        label2.shift();

        myLineChart3.update()
        console.log("Pulse")
    }, 1000);
}

function test_toggle() {
    if (wear===1) {
        wear = 0;
        document.getElementById(switch1).innerHTML = "off"
        document.getElementById(switch2).innerHTML = "off"

    }
    else if (wear===0) {
        wear = 1;
        document.getElementById(switch1).innerHTML = "on"
        document.getElementById(switch2).innerHTML = "on"
    }
    else {
        wear = 0;
        console.log("Something went wrong!")
    }
}

function test_indicator() {
    setInterval(function(){
        console.log(gps_str)
        gps_str += 1;
        update_indicator(gps_str);
        if (gps_str > 12) {
            gps_str = 0;
        }
    }, 200);
}




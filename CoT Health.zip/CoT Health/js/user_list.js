window.loggedin = false;

var user_ok = [
        {
            username: "anderszk@stud.ntnu.no",
            password: "admin"
        },
        {
            username: "haavarmk@stud.ntnu.no",
            password: "admin"
        },
        {
            username: "sacitas@stud.ntnu.no",
            password: "admin"
        },
        {
            username: "henraam@stud.ntnu.no",
            password: "admin"
        }
    ];



function getInfo() {
         var username = document.getElementById("user_name").value;
         var password = document.getElementById("password").value;
         if (window.loggedin === false) {
             for (let i = 0; i < user_ok.length; i++) {
                 if (username === user_ok[i].username && password === user_ok[i].password) {
                     alert("Login successful!");
                     console.log("Your username is:", username, "and your password is:", password);
                     window.loggedin = true;
                     window.open("control.html", "_self");
                     return;
                 }
             }
             alert("Wrong password!")
             window.open("login.html", "_self")
         }
         else if (window.loggedin === true) {
             alert("You are already logged in!");
             window.open("control.html", "_self");
         }
    }


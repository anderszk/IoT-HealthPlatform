var socket = io.connect('192.168.43.19:2520', {secure: false}); //This line declares a socket.io object to var "socket" and connects to the server
//The "secure: false" tells if the connection will be encrypted or not. Since we will not encrypt our connections, this is false.
let json = {};


//Socket.io has several functions. The .on function refers to what will happen when the client receive a call called 'connect' from the server
//View it as calling a function remotley. The server tells the client it wants to call this function with no arguments.
socket.on('connect',function() { //When you connect to the server (and it works) call this function
    console.log('Client has connected to the server!'); //The client prints this message
}); //The 'connect' function/identifier is the standard procedure. To make something more we have to make it ourselves

socket.on('clientConnected',function(id, ip) { //This is our selfmade functions. Here we can have the server return arguments (data) that we need
    console.log('Client recevied ID: ' + id); //In this case the server will tell us what our local ID is (auto assigned)
    console.log("Client IP: " + ip);//And it will tell us what our IP-address
});


/*
//In this function (which is essentially built up the same as a void function in Arduino) we want to send something to the server
//For this we use the other important Socket.io function, .emit(arg). Here we are telling our socket object so call the "changeLEDState" function
//on the server with the "state" argument. By calling the function on the server we mean that we send data to the server that tells it to do something
function changeLEDState(state) {
    //This function controls wether a LED-light is on or of
    socket.emit('changeLEDState', state); //Here the actual socket-object function is called. If we want a response we will have to set up a function (.on) like earlier.
    console.log("changeLEDState called");

}

function changeDriveState(state) {

    socket.emit('changeDriveState', state); //Same logic as earlier, this calls the change of motor direction
    console.log("changeDriveState called");

}

function changeTurnState(state) {

    socket.emit('changeTurnState', state);
    console.log("changeTurnState called");

}

function changeStopState(state) {

    socket.emit('changeStopState', state);
    console.log("changeStopState called");

}

function sendBuzzer(state) {
    socket.emit('buzz', state);
    console.log("Buzz-signal sent to ESP32!");
}
 */

//This function also emits something to the server. But in this case we want something a little bit more complex to happen.
//Since Arduino has a limited amount of timers, and using millis can be annoying, we have the possibilties of handing that task over to JavaScript on Node.js
//The function we are calling here will tell the server to set up a JavaScript timer, which then will periodically send a message to the ESP32 asking for data.
//Since the ESP32 easily can react to such a request it sends the data with no problems, and with no timers in use.
//This means we dont have to use the delay() function or the millis() function in Arduino, we can just let Node and JavaScript fix the tracking of time for us
//This is the function that will make the ESP32 transmit data to the server, and not the other way around
function requestDataFromBoard(interval) {
    socket.emit('requestDataFromBoard', interval); //Here we tell the server to call the function "requestDataFromBoard" with a argument called "intervall"
    //The intervall value is the period of time between each data transmit from the ESP32 to the server. Typical values can be everything form 100ms to 100s
    console.log("requestDataFromBoard was called with intervall: " + interval);
} //Be careful to not set the interval value to low, you do not want to overflood your server with data/requests

function stopDataFromBoard() { //Tells the server to stop all timers so that data is no longer sent from the ESP32 to the webpage
    socket.emit('stopDataFromBoard'); //Here we tell the server to call the function "stopDataFromBoard"
    console.log("stopDataFromBoard was called");
}






function getgps() {
    socket.emit("gps_allowed", 1)
    plotmap(lon, lat)
}


function user_on (data) {
    if (data === 1) {
        user_wear = "The user is wearing the device!";
        console.log("User active")
    }
    else if (data === 0) {
        user_wear = "The user is not wearing the device!";
        console.log("User inactive")
    }
    else {
        console.log("Something went wrong!");
    }
    document.getElementById("status").innerHTML = user_wear
}


function plotmap(lon, lat){
    var mapProp= {
        center:new google.maps.LatLng(lat, lon),
        zoom:13,
    };
    new google.maps.Map(document.getElementById("googleMap"),mapProp);
}

//Receives all data in JSON. In this way were able to extract the information effective and it also synchronize data and save space :)

socket.on('data', function(data){
    let peakbpm = 0;
    let peakhigh = 0;
    let peaklow = 0;
    console.log(JSON.stringify(data))

    dataArr1.push(data.temp);
    dataArr1.shift();
    label1.push(getTime());
    label1.shift()
    myLineChart.update();

    dataArr2.push(data.bpm);
    dataArr2.shift()
    label1.push(getTime());
    label1.shift()
    myLineChart2.update()

    lon = data.longitude;
    console.log(lon)
    lat = data.latitude;
    console.lkog(lat)

    var warning = data.prewarn;

    wear = data.wear;
    user_on(wear);
    check_wear = user_on(wear);

    if (data.temp <= peaklow) {
        peaklow += (data.temp - peaklow);
        console.log("l")
        document.getElementById("peak-low").innerHTML = "Min: "+peaklow;
    }
    else if (data.temp >= peakhigh) {
        peakhigh += (data.temp - peakhigh);
        console.log("h")
        document.getElementById("peak-high").innerHTML = "Max: "+peakhigh;
    }
    else {
        console.log("No new peak")
    }
    if (data.bpm >= peakbpm) {
        peakbpm += (data.bpm - peakbpm)
        document.getElementById("peak-bpm").innerHTML = peakbpm+"BPM";
    }
    device1_home = data.home;
    device1_connection = data.connection;
    device1_type = data.type;
    write_device(device1_type, device1_home, device1_connection, 1);

});

function getstatus(state) {
    if (rng === 1){
        fake_status = "Bracelet ON";
    }
    else if (rng === 0){
        fake_status = "Bracelet OFF"
    }
    else if (rng === 2){
        fake_status = "Bracelet Malfunction"
    }
    else {
        console.log("Something went wrong!");
    }
    document.getElementById("status").innerHTML = fake_status
    console.log("status changed");
}


/*
socket.on('json dev2', function(data){

    device1_home = data.home;
    device1_connection = data.connection;
    device1_type = data.type;
    write_device();
});

socket.on('json dev3', function(data){

    device2_home = data.home;
    device2_connection = data.connection;
    device2_type = data.type;
    write_device();
});

socket.on('json dev4', function(data){

    device3_home = data.home;
    device3_connection = data.connection;
    device3_type = data.type;
    write_device();
});

socket.on('json dev5', function(data){

    device4_home = data.home;
    device4_connection = data.connection;
    device4_type = data.type;
    write_device();
});
*/


var ctx = document.getElementById('myChart').getContext('2d'); //Defines the basic graphic element of the graph

var label1 = ["09:00","12","12","12","12","12","12","12","12","12"];

function checkTime(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function getTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    // add a zero in front of numbers<10
    m = checkTime(m);
    s = checkTime(s);
    labelx = h+":"+m+":"+s
    return labelx;
}


var myLineChart = new Chart(ctx, { //Defines the graph
    type: 'line', //Defines the type of graph
    data: { //Decides how the data (content of the graph will be)
        labels: label1,
        datasets: [ //Datasets refers to the different graphs and the data they contain
            {
                label: 'Grader Celsius [℃]', //Label of dataset/graph 1
                data: dataArr1, //The dataArray that actually stores the data
                backgroundColor: [
                    'rgb(181,90,90)'
                ],
                borderColor: [
                    'rgb(255,0,0)'
                ],
                borderWidth: 1, //The width of the graph line
                fill: false
            },
        ]
    },
    options: {
        hoverMode: 'index',
        stacked: false,
        position: 'left',
        scales: {
            yAxes: [{
                type: 'linear',
                ticks: {
                    stepWidth: 2,
                    start: -20,
                    steps: 8,
                gridLines: {
                        drawOnChartArea: false,
                }
                }
            }]
        },
        responsive: true,
        maintainAspectRatio: false
    }
});




var ktx = document.getElementById('myChart2').getContext('2d'); //Defines the basic graphic element of the graph

var myLineChart2 = new Chart(ktx, { //Defines the graph
    type: 'line', //Defines the type of graph
    data: { //Decides how the data (content of the graph will be)
        labels: label1, //Labels define the values of the x-axis (and can be altered at a later point/live)
        datasets: [ //Datasets refers to the different graphs and the data they contain
            {
                label: '[BPM]',
                data: dataArr2,
                backgroundColor: [
                    'rgb(181,90,90)'
                ],
                borderColor: [
                    'rgb(255,0,0)'
                ],
                borderWidth: 1,
                fill: false
            }
        ]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true //Keep this true to begin at zero in the graph
                }
            }]
        },
        responsive: true,
        maintainAspectRatio: false,
        hoverMode: 'index',
        stacked: false,
    }
});


let device1_home = "";
let device1_connection = "";
let device1_type = "";

let device2_home = "";
let device2_connection = "";
let device2_type = "";

let device3_home = "";
let device3_connection = "";
let device3_type = "";

let device4_home = "";
let device4_connection = "";
let device4_type = "";



function write_device(t, h, c, no){ //t = type, h = home, c = connection, no = device no.
    no = String(no)
    if (t.toLowerCase() === "esp32") {
        let image1 = document.getElementById('dev'+no+'_pic');
        image1.src = "bilder/arduinouno1.jpg"
        image1.style = "width: 500px; margin-top: 100px; align-items: flex-end"
    }
    else if (t.toLowerCase() === "arduino") {
        let image2 = document.getElementById('dev'+no+'_pic');
        image2.src = "bilder/esp32_1.jpg"
        image2.style = "width: 400px; margin-top: 100px; align-items: flex-end"
    }
    else {
        console.log("Type not supported")
    }
    document.getElementById("dev"+no+"_type").innerHTML = t;
    document.getElementById("dev"+no+"_home").innerHTML = h;
    document.getElementById("dev"+no+"_connection").innerHTML = c;
}





